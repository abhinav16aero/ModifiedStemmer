# -*- coding: utf-8 -*-

from .Test_Modified_Porterstemmer import *
