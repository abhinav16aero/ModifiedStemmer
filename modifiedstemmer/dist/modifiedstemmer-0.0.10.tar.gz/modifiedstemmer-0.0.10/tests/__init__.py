#!/usr/bin/env python
# -*- coding: utf-8 -*-


from .Test_Modified_stemmer import *
