#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'Abhinav Kumar'
__email__ = 'anu55abhi@gmail.com'
__version__ = '1.0'

from mod_stemmer import modifiedstemmer
