.. :changelog:

History
-------

0.1.0 (2024-06-22)
---------------------

* First release on PyPI.